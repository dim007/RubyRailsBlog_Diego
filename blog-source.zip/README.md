# README

* Ruby version - 2.5.5 p157

* System dependencies - Rails 5.2.3 | Sqlite3 3.28.0

* Configuration - TBD

* Database creation - TBD

* Database initialization - TBD

* How to run the test suite - TBD

* Services (job queues, cache servers, search engines, etc.) - TBD

* Deployment instructions - TBD

* ...
